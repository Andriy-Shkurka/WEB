function calculateSquare() {
    const numberInput = document.getElementById("numberInput").value;
    const resultElement = document.getElementById("result");

    if (!numberInput) {
        resultElement.textContent = "Введіть число!";
        return;
    }

    const number = parseFloat(numberInput);

    fetch("http://localhost:3000/calculate-square", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ number })
    })
    .then(response => response.json())
    .then(data => {
        if (data.error) {
            resultElement.textContent = data.error;
        } else {
            resultElement.textContent = `Квадрат числа: ${data.square}`;
        }
    })
    .catch(error => {
        console.error("Помилка:", error);
        resultElement.textContent = "Сталася помилка при запиті";
    });
}
