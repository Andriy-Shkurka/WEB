const express = require("express");
const cors = require("cors");

const app = express();
const PORT = 3000;

app.use(cors()); // Дозволяє роботу з AJAX-запитами
app.use(express.json()); // Декодування JSON

app.post("/calculate-square", (req, res) => {
    const { number } = req.body;

    if (typeof number !== "number" || isNaN(number)) {
        return res.status(400).json({ error: "Некоректне число" });
    }

    const square = number * number;
    res.json({ square });
});

app.listen(PORT, () => {
    console.log(`Сервер запущено на http://localhost:${PORT}`);
});
